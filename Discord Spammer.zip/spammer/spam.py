import requests

channelID = <channel id> # your channel id here
headers = {"authorization":"your token here"}

file = open("text.txt", "r")
lines = file.readlines()

for line in lines:
    requests.post(f"https://discord.com/api/v9/channels/{#channel id here}/messages",headers = headers,json = {"content": line})